<?php
	session_start();
	$username=$_SESSION['username'];
	$password=$_SESSION['password'];
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Practical Exam 1</title>
	<style type="text/css">
	
		#logOutBtn {
			margin: 0px 0px 0px 1000px;
		}
		.jumbotron-fluid {
			padding-bottom: 20px;
		}
	</style>
</head>
<body>
	<div class="jumbotron jumbotron-fluid text-center">
		<h2>Welcome <?php echo $username; ?></h2>
		<a href="login.php"><button id="logOutBtn" class="btn btn-success">Log out</button></a>
	</div>
	<div class="container">
		
	</div>
</body>
</html>