<?php
	if(isset($_POST['submit'])){
		session_start();

		$_SESSION['username'] = htmlentities($_POST['username']);
		$_SESSION['password'] = htmlentities($_POST['password']);
		header('Location: welcome.php');
	}
	if(isset($_POST['signUp'])){
		session_start();
		header('Location: signUp.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Practical Exam 1</title>
	<style type="text/css">
		.container {
			margin:300px 0px 0px 570px;
			padding: 10px 5px;
		}
		.form-group {
			padding: 0px 150px 0px 10px;
			display: inline-flex;
		}
		#btnLog {
			margin-left: 100px;
		}
	</style>
</head>
<body>
	
		<title></title>
		<div class="container">
			<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<div class="form-group">
					<label>Username </label>
					<input type="text" name="username" class="form-control" value="">
				</div><br>
				<div class="form-group">
					<label>Password </label>
					<input type="password" name="password" class="form-control" value="">
				</div>
				<br>
				<button type="submit" name="signUp" class="btn btn-danger" id="btnLog">Sign Up</button>
				<button type="submit" name="submit" class="btn btn-success">Log In</button>
			</form>
		</div>
	</div>

</body>
</html>