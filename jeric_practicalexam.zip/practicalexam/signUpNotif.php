<?php
	session_start();
	$fname = $_SESSION['fname'];
	$email = $_SESSION['email'];
	$uname = $_SESSION['uname'];
	$pwd = $_SESSION['pwd'];
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Practical Exam 1</title>
</head>
<body>
	<div class="jumbotron jumbotron-fluid text-center" style="padding-bottom: 30px;">
		<h2>Congratulations <?php echo $fname; ?>!!! You have successfully created an account</h2><br>
		<h3>Here are your details</h3><br>
		<h5>Email: <?php echo $email; ?></h5>
		<h5>Username: <?php echo $uname; ?></h5>
		<h5>Password: <?php echo $pwd; ?></h5><br><br>
		<a href="login.php"><button class="btn btn-danger">Click here to Log In</button></a>
	</div>
</body>
</html>