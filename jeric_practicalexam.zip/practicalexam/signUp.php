<?php
	if(isset($_POST['submit'])){
		session_start();
		$_SESSION['fname'] = htmlentities($_POST['fname']);
		$_SESSION['email'] = htmlentities($_POST['email']);
		$_SESSION['uname'] = htmlentities($_POST['uname']);
		$_SESSION['pwd'] = htmlentities($_POST['pwd']);
		header('Location: signUpNotif.php');
	}
?>  
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Practical Exam 1</title>
	<style type="text/css">
		.container {
			margin: 100px 0px 0px 130px;
		}
	</style>
</head>
<body>
	<div class="container">
		<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<div class="form-group">
			<label>First Name</label>
			<input type="text" name= "fname" class="form-control" value="" required="">
		</div>
		<div class="form-group">
			<label>Last Name</label>
			<input type="text" name= "lname" class="form-control" value="" >
		</div>
		<div class="form-group">
			<label>Email</label>
			<input type="text" name= "email" class="form-control" value="" required="">
		</div>
		<div class="form-group">
			<label>Username</label>
			<input type="text" name= "uname" class="form-control" value="" required="">
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="text" name= "pwd" class="form-control" value="" required="">
		</div>
		<button type="submit" name="submit" class="btn btn-primary">Create Account</button>
	</form>
</div>
</body>
</html>